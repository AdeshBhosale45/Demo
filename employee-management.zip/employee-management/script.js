const employees = JSON.parse(localStorage.getItem('employees')) || [];
const employeesPerPage = 5;
let currentPage = 1;

// Store a new employee in local storage
function storeEmployee(employee) {
    employees.push(employee);
    localStorage.setItem('employees', JSON.stringify(employees));
}

// Display employees on the employee list page
function displayEmployees(employeeList) {
    const tableBody = document.querySelector('#employee-table tbody');
    tableBody.innerHTML = '';

    if (employeeList.length === 0) {
        const row = tableBody.insertRow();
        const cell = row.insertCell(0);
        cell.colSpan = 5;
        cell.textContent = 'No employees found.';
        return;
    }

    employeeList.forEach(employee => {
        const row = tableBody.insertRow();
        row.innerHTML = `
            <td>${employee.name}</td>
            <td>${employee.position}</td>
            <td>${employee.about}</td>
            <td>${employee.joining_date}</td>
            <td>
                <button onclick="deleteEmployee(${employee.id})">Delete</button>
            </td>
        `;
    });
}

// Delete an employee by ID
function deleteEmployee(id) {
    const index = employees.findIndex(employee => employee.id === id);
    if (index !== -1) {
        employees.splice(index, 1);
        localStorage.setItem('employees', JSON.stringify(employees));
        displayEmployees(getPaginatedEmployees());
    }
}

// Search employees
function searchEmployees(searchTerm) {
    const filteredEmployees = employees.filter(employee =>
        employee.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    displayEmployees(filteredEmployees);
}

// Get paginated employees
function getPaginatedEmployees() {
    const startIndex = (currentPage - 1) * employeesPerPage;
    const endIndex = startIndex + employeesPerPage;
    return employees.slice(startIndex, endIndex);
}

// Update pagination buttons
function updatePagination() {
    const paginationContainer = document.getElementById('pagination');
    paginationContainer.innerHTML = '';
    const totalPages = Math.ceil(employees.length / employeesPerPage);

    for (let i = 1; i <= totalPages; i++) {
        const button = document.createElement('button');
        button.textContent = i;
        button.className = 'pagination-button';
        if (i === currentPage) {
            button.classList.add('active');
        }
        button.addEventListener('click', () => {
            currentPage = i;
            displayEmployees(getPaginatedEmployees());
            updatePagination();
        });
        paginationContainer.appendChild(button);
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('employee-form')) {
        document.getElementById('employee-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const position = document.getElementById('position').value;
            const about = document.getElementById('about').value;
            const joiningDate = document.getElementById('joining_date').value;

            const newEmployee = {
                id: Date.now(),
                name,
                position,
                about,
                joining_date: joiningDate
            };
            storeEmployee(newEmployee);
            alert('Employee Registered');
            e.target.reset();
        });
    }

    if (document.getElementById('employee-table')) {
        displayEmployees(getPaginatedEmployees());
        updatePagination();
    }

    if (document.getElementById('search-input')) {
        document.getElementById('search-input').addEventListener('input', (e) => {
            searchEmployees(e.target.value);
        });
    }
});
